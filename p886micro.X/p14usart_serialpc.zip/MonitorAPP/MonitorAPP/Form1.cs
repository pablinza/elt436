﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonitorAPP
{
    public partial class Form1 : Form
    {
        private string msg;
        private int val;
        public Form1()
        { 
            InitializeComponent();
            foreach (string slist in System.IO.Ports.SerialPort.GetPortNames())
                comboBox1.Items.Add(slist);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                serialPort1.PortName = comboBox1.SelectedItem.ToString();
                serialPort1.Open();
                label2.Text = "Puerto Listo";
            }
            else
            {
                serialPort1.Close();
                label2.Text = "Puerto Cerrado";
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            val = serialPort1.ReadChar();
            this.Invoke(new EventHandler(Lectura));
        }
        private void Lectura(object sender, EventArgs e)
        {
            if (val == '1') //Si esta presionado BT1
                panel1.BackColor = Color.FromArgb(0, 200, 0);
            if(val == '0')
                panel1.BackColor = Color.FromArgb(0, 64, 0);
            if (val == '3') //Si esta presionado BT2
                panel2.BackColor = Color.FromArgb(0, 200, 0);
            if (val == '2')
                panel2.BackColor = Color.FromArgb(0, 64, 0);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
                serialPort1.Write("1");
            else
                serialPort1.Write("0");
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
                serialPort1.Write("2");
            else
                serialPort1.Write("3");
        }
    }
}
