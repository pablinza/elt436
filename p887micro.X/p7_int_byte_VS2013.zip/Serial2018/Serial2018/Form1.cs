﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Serial2018
{
    public partial class Form1 : Form
    {
        public int val;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.PortName = "COM5";
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
            label1.BackColor = Color.DarkGreen;
            label1.Text = "SW";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                serialPort1.Write("1");
            }
            else
                serialPort1.Write("0");
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            val = serialPort1.ReadChar();
            this.Invoke(new EventHandler(Lectura));
        }
        private void Lectura(object sender, EventArgs e)
        {
            if(val == '1')
            {
                label1.BackColor = Color.Lime;
            }
            if(val == '0')
            {
                label1.BackColor = Color.DarkGreen;
            }
        }

    }
}
